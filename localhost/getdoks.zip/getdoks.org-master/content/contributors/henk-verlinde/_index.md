---
title: "Henk Verlinde"
description: "Creator of Hyas."
date: 2020-10-06T08:50:45+00:00
lastmod: 2020-10-06T08:50:45+00:00
draft: false
images: []
---

Creator of Hyas.

[@HenkVerlinde](https://twitter.com/henkverlinde)
