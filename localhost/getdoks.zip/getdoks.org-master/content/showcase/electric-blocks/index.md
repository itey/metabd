---
title: "Electric Blocks"
description: "Electric Blocks is a Minecraft Forge mod that allows you to run realistic power flow simulations for educational and engineering purposes. This site contains documentation for using this mod."
lead: "Electric Blocks is a Minecraft Forge mod that allows you to run realistic power flow simulations for educational and engineering purposes. This site contains documentation for using this mod."
date: 2021-03-04T08:02:23+01:00
lastmod: 2021-03-04T08:02:23+01:00
draft: false
images: ["electric-blocks.png"]
link: "https://electricblocks.github.io"
menu:
  showcase:
    parent: "browse"
weight: 060
toc: false
pinned: false
types: ["project"]
functionalities: ["blog", "dark mode", "search"]
---

This mod is sponsored by the University of Idaho as part of the Capstone Design project.
