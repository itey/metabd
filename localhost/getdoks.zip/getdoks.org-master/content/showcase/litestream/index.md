---
title: "Litestream"
description: "Stop building slow, complex, fragile software systems. Safely run your application on a single server."
lead: "Stop building slow, complex, fragile software systems. Safely run your application on a single server."
date: 2021-06-07T20:13:28+02:00
lastmod: 2021-06-07T20:13:28+02:00
draft: false
images: ["litestream.png"]
link: "https://litestream.io"
menu:
  showcase:
    parent: "browse"
weight: 090
toc: false
pinned: false
types: ["hardware"]
functionalities: ["blog", "custom font"]
---
