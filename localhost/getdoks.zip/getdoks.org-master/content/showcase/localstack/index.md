---
title: "LocalStack"
description: "A fully functional local cloud stack. Develop and test your cloud and serverless apps offline!"
lead: "A fully functional local cloud stack. Develop and test your cloud and serverless apps offline!"
date: 2021-08-13T10:52:09+02:00
lastmod: 2021-08-13T10:52:09+02:00
draft: false
images: ["localstack.png"]
link: "https://localstack.cloud"
menu:
  showcase:
    parent: "browse"
weight: 150
toc: false
pinned: false
types: ["developer"]
functionalities: ["blog"]
---
