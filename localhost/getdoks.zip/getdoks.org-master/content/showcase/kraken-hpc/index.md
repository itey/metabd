---
title: "Kraken HPC"
description: "Kraken HPC is an ecosystem of tools for managing and automating distributed systems."
lead: "Kraken HPC is an ecosystem of tools for managing and automating distributed systems."
date: 2021-08-13T10:42:54+02:00
lastmod: 2021-08-13T10:42:54+02:00
draft: false
images: ["kraken-hpc.png"]
link: "https://kraken-hpc.io"
menu:
  showcase:
    parent: "browse"
weight: 120
toc: false
pinned: false
types: ["project"]
functionalities: ["blog", "dark mode"]
---
