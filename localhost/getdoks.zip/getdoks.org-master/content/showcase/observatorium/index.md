---
title: "Observatorium"
description: "Observatorium allows you to run and operate effectively a multi-tenant, easy to operate, scalable open source observability system on Kubernetes. "
lead: "Observatorium allows you to run and operate effectively a multi-tenant, easy to operate, scalable open source observability system on Kubernetes. "
date: 2021-08-13T10:49:35+02:00
lastmod: 2021-08-13T10:49:35+02:00
draft: false
images: ["observatorium.png"]
link: "https://observatorium.io"
menu:
  showcase:
    parent: "browse"
weight: 140
toc: false
pinned: false
types: ["project"]
functionalities: ["dark mode", "breadcrumb"]
---
