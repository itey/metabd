---
title: "causalscience.org"
description: "Causal Data Science Meeting 2021. The Causal Data Science Meeting aims to bring experts from industry and science together. Participation is free of charge."
lead: "Causal Data Science Meeting 2021. The Causal Data Science Meeting aims to bring experts from industry and science together. Participation is free of charge."
date: 2021-11-16T12:20:40+01:00
lastmod: 2021-11-16T12:20:40+01:00
draft: false
images: ["causalscience.org.png"]
link: "https://www.causalscience.org"
menu:
  showcase:
    parent: "browse"
weight: 200
toc: false
pinned: true
types: ["university"]
functionalities: ["blog", "search", "custom font"]
---
