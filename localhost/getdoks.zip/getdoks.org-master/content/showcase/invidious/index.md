---
title: "Invidious"
description: "Invidious is an open source alternative front-end to YouTube."
lead: "Invidious is an open source alternative front-end to YouTube."
date: 2021-11-16T12:05:06+01:00
lastmod: 2021-11-16T12:05:06+01:00
draft: false
images: ["invidious.png"]
link: "https://invidious.io"
menu:
  showcase:
    parent: "browse"
weight: 180
toc: false
pinned: false
types: ["software"]
functionalities: ["dark mode"]
---
