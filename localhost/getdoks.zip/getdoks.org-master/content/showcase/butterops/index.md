---
title: "ButterOps"
description: "We're a group of developers, creating world class open-sourced products and helping fellow devs, to grow their side projects into sustainable startups."
lead: "We're a group of developers, creating world class open-sourced products and helping fellow devs, to grow their side projects into sustainable startups."
date: 2021-02-19T12:04:41+01:00
lastmod: 2021-02-19T12:04:41+01:00
draft: false
images: ["butterops.png"]
link: "https://www.butterops.dev"
menu:
  showcase:
    parent: "browse"
weight: 050
toc: false
pinned: false
types: ["developer"]
functionalities: ["dark mode", "search"]
---
