---
title: "Neutrino Oscillations"
description: "A free ebook on neutrino flavor conversions in dense media. Neutrino flavor conversions in dense media play important roles in the physical and chemical evolutions of many dense environments. "
lead: "A free ebook on neutrino flavor conversions in dense media. Neutrino flavor conversions in dense media play important roles in the physical and chemical evolutions of many dense environments."
date: 2020-12-31T14:40:12+01:00
lastmod: 2020-12-31T14:40:12+01:00
draft: false
images: ["neutrino-oscillations.png"]
link: "https://neutrino.leima.is"
menu:
  showcase:
    parent: "browse"
weight: 020
toc: false
pinned: false
types: ["ebook"]
functionalities: ["dark mode", "search", "KaTeX"]
---
