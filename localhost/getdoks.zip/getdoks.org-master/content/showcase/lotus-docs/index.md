---
title: "Lotus Docs"
description: "Lotus is the reference implementation for the Filecoin network. It is written in Go, and is maintained by the Protocol Labs team."
lead: "Lotus is the reference implementation for the Filecoin network. It is written in Go, and is maintained by the Protocol Labs team."
date: 2021-11-16T12:09:59+01:00
lastmod: 2021-11-16T12:09:59+01:00
draft: false
images: ["lotus-docs.png"]
link: "https://lotu.sh"
menu:
  showcase:
    parent: "browse"
weight: 190
toc: false
pinned: false
types: ["application"]
functionalities: ["dark mode", "search", "mermaid", "highlight.js"]
---
