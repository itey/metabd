---
title: "K8E"
description: "Simple Kubernetes Distribution. The k8e 🚀 (said 'kuber easy') project builds on upstream project K3s as codebase, remove Edge/IoT features and extend enterprise features with best practices."
lead: "Simple Kubernetes Distribution. The k8e 🚀 (said 'kuber easy') project builds on upstream project K3s as codebase, remove Edge/IoT features and extend enterprise features with best practices."
date: 2021-08-13T10:36:53+02:00
lastmod: 2021-08-13T10:36:53+02:00
draft: false
images: ["k8e.png"]
link: "https://getk8e.com"
menu:
  showcase:
    parent: "browse"
weight: 110
toc: false
pinned: false
types: ["project"]
functionalities: ["blog", "dark mode", "search", "highlight.js"]
---
