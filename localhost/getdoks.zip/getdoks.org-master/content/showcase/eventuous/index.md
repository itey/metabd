---
title: "Eventuous"
description: "Building blocks for production-grade applications with Event Sourcing in heart. Very opinionated, highly volatile."
lead: "Building blocks for production-grade applications with Event Sourcing in heart. Very opinionated, highly volatile."
date: 2021-06-07T19:57:43+02:00
lastmod: 2021-06-07T19:57:43+02:00
draft: false
images: ["eventuous.png"]
link: "https://eventuous.dev"
menu:
  showcase:
    parent: "browse"
weight: 070
toc: false
pinned: false
types: ["application"]
functionalities: ["blog", "dark mode", "search"]
---
