---
title: "Prometheus Operator"
description: "The Prometheus Operator manages Prometheus clusters atop Kubernetes."
lead: "The Prometheus Operator manages Prometheus clusters atop Kubernetes."
date: 2021-06-07T20:06:02+02:00
lastmod: 2021-06-07T20:06:02+02:00
draft: false
images: ["prometheus-operator.png"]
link: "https://prometheus-operator.dev"
menu:
  showcase:
    parent: "browse"
weight: 080
toc: false
pinned: false
types: ["developer"]
functionalities: []
---
