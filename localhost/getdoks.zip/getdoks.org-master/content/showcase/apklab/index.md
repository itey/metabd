---
title: "APKLab"
description: "The ultimate Android RE experience right inside your VS Code."
lead: "The ultimate Android RE experience right inside your VS Code."
date: 2021-11-16T12:00:35+01:00
lastmod: 2021-11-16T12:00:35+01:00
draft: false
images: ["apklab.png"]
link: "https://apklab.surendrajat.xyz"
menu:
  showcase:
    parent: "browse"
weight: 170
toc: false
pinned: false
types: ["developer"]
functionalities: ["blog", "dark mode", "search"]
---
