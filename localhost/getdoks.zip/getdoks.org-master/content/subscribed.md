---
title: "Subscribed"
description: "You're subscribed to Doks newsletter! The next edition will end up in your inbox."
date: 2021-03-02T18:31:48+01:00
lastmod: 2021-03-02T18:31:48+01:00
draft: false
sitemap_exclude: true
feed_exclude: true
robots: noindex, nofollow, noarchive
type: "confirmation"
images: []
---

You're subscribed to the Doks newsletter! The next edition will end up in your inbox.
