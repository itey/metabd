---
title: "Blog"
description: "Follow our mission to make the easiest and most fun Hugo theme for building modern documentation websites."
date: 2020-10-06T08:49:55+00:00
lastmod: 2020-10-06T08:49:55+00:00
draft: false
images: []
---

Follow our mission to make the easiest and most fun Hugo theme for building modern documentation websites.
