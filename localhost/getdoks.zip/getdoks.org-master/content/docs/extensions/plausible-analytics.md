---
title: "Plausible Analytics"
description: "How to add Plausible Analytics to your Doks website."
lead: "How to add Plausible Analytics to your Doks website."
date: 2020-11-17T14:55:51+01:00
lastmod: 2020-11-17T14:55:51+01:00
draft: false
images: []
menu:
  docs:
    parent: "extensions"
weight: 450
toc: true
---

## Resources

- [Plausible Analytics](https://plausible.io/)
