---
title: "Google Fonts"
description: "How to add Google Fonts to your Doks website."
lead: "How to add Google Fonts to your Doks website."
date: 2020-11-17T14:55:39+01:00
lastmod: 2020-11-17T14:55:39+01:00
draft: false
images: []
menu:
  docs:
    parent: "extensions"
weight: 440
toc: true
---

## Demo

- Available soon

## Resources

- [Google Fonts Jost](https://fonts.google.com/specimen/Jost)
- [Google Webfonts Helper](https://google-webfonts-helper.herokuapp.com/fonts)
