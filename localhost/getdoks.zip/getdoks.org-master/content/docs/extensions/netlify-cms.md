---
title: "Netlify CMS"
description: "How to add Netlify CMS to your Doks website."
lead: "How to add Netlify CMS to your Doks website."
date: 2020-11-23T10:05:07+01:00
lastmod: 2020-11-23T10:05:07+01:00
draft: false
images: []
menu:
  docs:
    parent: "extensions"
weight: 460
toc: true
---

## Resources

- [Netlify CMS](https://www.netlifycms.org/)
