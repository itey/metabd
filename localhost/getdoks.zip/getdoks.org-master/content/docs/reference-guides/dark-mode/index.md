---
title: "Dark Mode"
description: "Switch to a low-light UI with the click of a button. Change colors with variables to match your branding."
lead: "Switch to a low-light UI with the click of a button. Change colors with variables to match your branding."
date: 2020-11-10T11:39:06+01:00
lastmod: 2020-11-10T11:39:06+01:00
draft: false
images: []
menu: 
  docs:
    parent: "reference-guides"
weight: 390
toc: true
---

{{< img-simple src="dark-mode.gif" alt="Dark Mode Doks" >}}
