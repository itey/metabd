# Doks website

[![CodeQL](https://github.com/h-enk/getdoks.org/actions/workflows/codeql-analysis.yml/badge.svg)](https://github.com/h-enk/getdoks.org/actions/workflows/codeql-analysis.yml)
[![Hyas CI](https://github.com/h-enk/getdoks.org/actions/workflows/node.js-ci.yml/badge.svg)](https://github.com/h-enk/getdoks.org/actions/workflows/node.js-ci.yml)
[![Netlify Status](https://api.netlify.com/api/v1/badges/45c6b49f-bff3-47e8-9a6d-17ecd48a179a/deploy-status)](https://app.netlify.com/sites/getdoks/deploys)
